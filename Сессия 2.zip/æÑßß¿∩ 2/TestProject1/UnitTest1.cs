using WSUniversalLib;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        Calculation calculation = new Calculation();
        [TestMethod]
        public void GetQuantityForProduct_ValidInputs_ReturnsExpectedResult()
        {
            int productType = 3;
            int materialType = 1;
            int count = 15;
            float width = 20;
            float length = 45;

            int expectedResult = 114148;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void GetQuantityForProduct_NonExistentProductType_ReturnsMinusOne()
        {
            int productType = 4;
            int materialType = 1;
            int count = 15;
            float width = 20;
            float length = 45;

            int expectedResult = -1;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetQuantityForProduct_NonExistentMaterialType_ReturnsMinusOne()
        {
            int productType = 3;
            int materialType = 3;
            int count = 15;
            float width = 20;
            float length = 45;

            int expectedResult = -1;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetQuantityForProduct_ZeroCount_ReturnsMinusOne()
        {
            int productType = 3;
            int materialType = 1;
            int count = 0;
            float width = 20;
            float length = 45;

            int expectedResult = -1;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetProductForProduct_ZeroWidth_ReturnsMinusOne()
        {
            int productType = 3;
            int materialType = 1;
            int count = 15;
            float width = 0;
            float length = 45;

            int expectedResult = -1;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetProductForProduct_ZeroLength_ReturnsMinusOne()
        {
            int productType = 3;
            int materialType = 1;
            int count = 15;
            float width = 20;
            float length = 0;

            int expectedResult = -1;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetQuantityForProduct_NegativeLength_ReturnsMinusOne()
        {
            int productType = 3;
            int materialType = 1;
            int count = 15;
            float width = -20;
            float length = 45;

            int expectedResult = -1;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetQuantityForProduct_NegativeWidth_ReturnsMinusOne()
        {
            int productType = 3;
            int materialType = 1;
            int count = 15;
            float width = 20;
            float length = -45;

            int expectedResult = -1;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetQuantityForProduct_LargeWidth_ReturnsExpectedResult()
        {
            int productType = 3;
            int materialType = 1;
            int count = 15;
            float width = 20f;
            float length = 10000f;

            int expectedResult = 25366098;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetQuantityForProduct_LargeCount_ReturnsExpectedResult()
        {
            int productType = 2;
            int materialType = 2;
            int count = 444;
            float width = 20;
            float length = 45;

            int expectedResult = 3378764;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetQuantityForProduct_ProductTypeWithHighestCoefficient_ReturnsExpectedResult()
        {
            int productType = 3;
            int materialType = 1;
            int count = 15;
            float width = 20;
            float length = 45;

            int expectedResult = 114148;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void GetQuantityForProduct_ProductTypeWithLowestCoefficient_ReturnsExpectedResult()
        {
            int productType = 1;
            int materialType = 1;
            int count = 15;
            float width = 20;
            float length = 45;

            int expectedResult = 14895;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetQuantityForProduct_MaterialTypeWithHighestBrakePercentage_ReturnsExpectedResult()
        {
            int productType = 3;
            int materialType = 1;
            int count = 15;
            float width = 20;
            float length = 45;

            int expectedResult = 114148;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void GetQuantityForProduct_MaterialTypeWithLowestBrakePercentage_ReturnsExpectedResult()
        {
            int productType = 2;
            int materialType = 2;
            int count = 10;
            float width = 15;
            float length = 30;

            int expectedResult = 11264;
            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);
        }
        
        [TestMethod]
        public void GetQuantityForProduct_StressTesting_ReturnsExpectedResult()
        {
            Random rand = new Random();
            int productType = rand.Next(1, 4);
            int materialType = rand.Next(1, 3);
            int count = rand.Next(1, 50);
            float width = rand.Next(1, 50);
            float length = rand.Next(1, 50);

            float productArea = width * length;
            float productCoefficient = productType == 1 ? 1.1f : productType == 2 ? 2.5f : 8.43f;
            float reqMaterial = productArea * count * productCoefficient;
            float materialBrake = materialType == 1 ? 0.003f : 0.0012f;
            int expectedResult = (int)Math.Ceiling(reqMaterial / (1 - materialBrake));

            int actualResult = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(expectedResult, actualResult);

        }
    }
}