﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WSUniversalLib
{
    public class Calculation
    {
        private const float _productType1Coefficient = 1.1f;
        private const float _productType2Coefficient = 2.5f;
        private const float _productType3Coefficient = 8.43f;

        private const float _materialType1BrakePercentage = 0.3f / 100;
        private const float _materialType2BrakePercentage = 0.12f / 100;
        public int GetQuantityForProduct(int productType, int materialType, int count, float width, float length)
        {
            float materialTypeBrakePercentage;
            float productTypeCoefficient;

            if (productType < 1 || productType > 3 || materialType < 1 || materialType > 2 || count <= 0 || width <= 0 || length <= 0)
            {
                return -1;
            }

            float _productArea = (float)width * (float)length;
            

            if (productType == 1)
            {
                productTypeCoefficient = _productType1Coefficient;
            }
            else if (productType == 2)
            {
                productTypeCoefficient = _productType2Coefficient;
            }
            else
            {
                productTypeCoefficient = _productType3Coefficient;
            }

            float requiredQualityMaterial = _productArea * productTypeCoefficient * count;
            

            if (materialType == 1)
            {
                materialTypeBrakePercentage = _materialType1BrakePercentage;
            }
            else
            {
                materialTypeBrakePercentage = _materialType2BrakePercentage;
            }

            float totalRequiredMaterial = requiredQualityMaterial / (1 - materialTypeBrakePercentage);
            return (int)Math.Ceiling(totalRequiredMaterial);
        }
    }
}
