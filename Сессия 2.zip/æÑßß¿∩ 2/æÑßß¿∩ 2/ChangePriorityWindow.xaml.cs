﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Сессия_2
{
    public partial class ChangePriorityWindow : Window
    {
        public int _newPriority { get; private set; }
        public static Агенты _агентCurrent = new Агенты();
        public ChangePriorityWindow(int max)
        {
            InitializeComponent();
            changePrior.Text = max.ToString();
        }
        private void buttonChangePriority_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(changePrior.Text, out int newPriority))
            {
                _newPriority = newPriority;
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("Необходимо ввести числовое значение");
            }
        }

        private void buttonCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
