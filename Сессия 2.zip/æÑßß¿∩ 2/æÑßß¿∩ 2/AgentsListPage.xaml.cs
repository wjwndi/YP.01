﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Сессия_2
{
    public partial class AgentsListPage : Page
    {
        public Агенты _агент;
        public int _currentPage = 1;
        public int _totalPages;
        public int _pageSize = 10;

        public AgentsListPage()
        {
            InitializeComponent();
            List<Типы> _allTypeFilter = КомпанияEntities.GetContext().Типы.ToList();
            _allTypeFilter.Insert(0, new Типы { Наименование_типа = "Все типы" });
            comboboxFilter.ItemsSource = _allTypeFilter;
            comboboxFilter.SelectedIndex = 0;
            comboboxSorting.SelectedIndex = 0;
            UpdateAgentsPage();
        }
        private void UpdateAgentsPage()
        {
            _totalPages = КомпанияEntities.GetContext().Агенты.Count() / _pageSize;
            var _pageData = КомпанияEntities.GetContext().Агенты.OrderBy(p => p.ID).Skip((_currentPage - 1) * _pageSize).Take(_pageSize).ToList();
            LViewTours.ItemsSource = _pageData.ToList();
        }
        private void UpdateAgentsAll()
        {
            var _pageData = КомпанияEntities.GetContext().Агенты.ToList();

            _pageData = _pageData.Where(p => p.Электронная_почта.Contains(textboxSearch.Text) || p.Телефон.Contains(textboxSearch.Text)).ToList();

            if (comboboxFilter.SelectedIndex != 0)
            {
                Типы _тип = comboboxFilter.SelectedItem as Типы;
                _pageData = _pageData.Where(p => p.ID_Тип == _тип.ID).ToList();
            }

            if (comboboxSorting.SelectedIndex == 1 && comboboxSortingType.SelectedIndex == 0)
            {
                _pageData = _pageData.OrderBy(p => p.Наименование).ToList();
            }
            else if (comboboxSorting.SelectedIndex == 1 && comboboxSortingType.SelectedIndex == 1)
            {
                _pageData = _pageData.OrderBy(p => p.Приоритет).ToList();
            }
            else if (comboboxSorting.SelectedIndex == 2 && comboboxSortingType.SelectedIndex == 0)
            {
                _pageData = _pageData.OrderByDescending(p => p.Наименование).ToList();
            }
            else if (comboboxSorting.SelectedIndex == 2 && comboboxSortingType.SelectedIndex == 1)
            {
                _pageData = _pageData.OrderByDescending(p => p.Приоритет).ToList();
            }

            LViewTours.ItemsSource = _pageData.ToList();
        }
        private void buttonClear_Click(object sender, RoutedEventArgs e)
        {
            textboxSearch.Clear();
            comboboxFilter.SelectedIndex = 0;
            comboboxSorting.SelectedIndex = 0;
            UpdateAgentsPage();
        }
        private void textboxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateAgentsAll();
        }
        private void comboboxFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateAgentsAll();
        }
        private void comboboxSorting_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateAgentsAll();
        }
        private void LViewTours_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var _agentsChange = new AgentsAddChangeWindow(LViewTours.SelectedItem as Агенты)
            {
                Title = "Редактирование агента"
            };
            _agentsChange.ShowDialog();
            UpdateAgentsPage();
        }
        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            var _agentsAdd = new AgentsAddChangeWindow(null)
            {
                Title = "Добавление агента"
            };
            _agentsAdd.ShowDialog();
            UpdateAgentsPage();
        }
        private void buttonDelete_Click(object sender, RoutedEventArgs e)
        {
            var agentsRemoving = LViewTours.SelectedItems.Cast<Агенты>().ToList();
            if (agentsRemoving.Count > 0)
            {
                if (MessageBox.Show($"Вы точно хотите удалить?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        КомпанияEntities.GetContext().Агенты.RemoveRange(agentsRemoving);
                        КомпанияEntities.GetContext().SaveChanges();
                        MessageBox.Show("Данные удалены");
                        UpdateAgentsPage();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
            }
        }
        private void buttonPreviousPage_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage > 1)
            {
                _currentPage--;
                UpdateAgentsPage();
            }
        }
        private void buttonNextPage_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage < _totalPages)
            {
                _currentPage++;
                UpdateAgentsPage();
            }
        }
        private void buttonChangePriority_Click(object sender, RoutedEventArgs e)
        {
            var selectedAgents = LViewTours.SelectedItems.Cast<Агенты>();
            var agentsPriority = selectedAgents.Max(a => Convert.ToInt32(a.Приоритет));
            ChangePriorityWindow window = new ChangePriorityWindow(agentsPriority);
            window.ShowDialog();
            if (window.DialogResult == true)
            {
                try
                {
                    using (var context = new КомпанияEntities())
                    {
                        foreach (var agent in selectedAgents)
                        {
                            var _agents = context.Агенты.FirstOrDefault(a => a.ID == agent.ID);
                            if (_agents != null)
                            {
                                _agents.Приоритет = window._newPriority.ToString();
                            }
                            else
                            {
                                MessageBox.Show("Агенты не найдены!");
                            }
                        }
                        context.SaveChanges();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"{ex.Message}");
                }
            }
            UpdateAgentsPage();
        }
        private void LViewTours_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            buttonChangePriority.IsEnabled = true;
        }
        private void comboboxSortingType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateAgentsAll();
        }
    }
}
