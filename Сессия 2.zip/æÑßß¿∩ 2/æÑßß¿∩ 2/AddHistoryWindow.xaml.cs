﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Сессия_2
{
    public partial class AddHistoryWindow : Window
    {
        public Агенты _агентCurrent = new Агенты();
        public Агенты_и_продукция _агенты_И_Продукция = new Агенты_и_продукция();
        public AddHistoryWindow(Агенты агент)
        {
            InitializeComponent();
            if (агент != null)
            {
                _агентCurrent = агент;
            }
            comboboxType.ItemsSource = КомпанияEntities.GetContext().Продукция.ToList();
        }

        private void buttonCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (_агенты_И_Продукция.ID_Продукция == 0)
                errors.AppendLine("Выберите продукцию");
            if (_агенты_И_Продукция.Количество_продукции <= 0)
                errors.AppendLine("Укажите количество продукции");
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }
            КомпанияEntities.GetContext().Агенты_и_продукция.Add(_агенты_И_Продукция);

            try
            {
                КомпанияEntities.GetContext().SaveChanges();
                MessageBox.Show("Сохранено");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
