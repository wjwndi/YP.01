﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Сессия_2
{
    public partial class HistoryOfAgentWindow : Window
    {
        public static Агенты _агентCurrent = new Агенты();
        private static List<Агенты_и_продукция> _payments;
        public HistoryOfAgentWindow(Агенты агент)
        {
            InitializeComponent();
            _агентCurrent = агент;
            UpdateProducts();
        }

        private void buttonAddProduct_Click(object sender, RoutedEventArgs e)
        {
            AddHistoryWindow addHistoryWindow = new AddHistoryWindow(_агентCurrent);
            addHistoryWindow.Show();
            UpdateProducts();
        }

        private void buttonDeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            var _products = datagridProducts.SelectedItems.Cast<Агенты_и_продукция>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    КомпанияEntities.GetContext().Агенты_и_продукция.RemoveRange(_products);
                    КомпанияEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    UpdateProducts();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }

            }
        }
        private void UpdateProducts()
        {
            _payments = КомпанияEntities.GetContext().Агенты_и_продукция.Where(p => p.ID_Агенты == _агентCurrent.ID).ToList();
            datagridProducts.ItemsSource = _payments;
        }
    }
}
